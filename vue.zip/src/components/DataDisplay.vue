<template>
  <div>
    <h2>Data Display Component</h2>
    <table>
      <thead>
        <tr>
          <th>Column 1</th>
          <th>Column 2</th>
          <!-- Добавьте заголовки для своих данных -->
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in data" :key="item.id">
          <td>{{ item.column1 }}</td>
          <td>{{ item.column2 }}</td>
          <!-- Замените "column1" и "column2" на ваши данные из базы данных -->
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  props: {
    data: Array, // Передавайте данные сюда из родительского компонента
  },
};
</script>
