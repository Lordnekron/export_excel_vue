<template>
  <div>
    <h1>Vue Excel Export App</h1>
    <DataDisplay :data="data" />
    <!-- Подключите компонент отображения данных -->
    <ExportButton :data="data" />
    <!-- Подключите компонент кнопки экспорта -->
  </div>
</template>

<script>
import DataDisplay from "./components/DataDisplay.vue";
import ExportButton from "./components/ExportButton.vue";

export default {
  components: {
    DataDisplay,
    ExportButton,
  },
  data() {
    return {
      data: [
        {
          column1: "Valueывмывуцацирвыупрамуыаыгугапцгнфычы1",
          column2: "Value2",
        },
        // Замените это на данные из вашей базы данных
      ],
    };
  },
};
</script>
