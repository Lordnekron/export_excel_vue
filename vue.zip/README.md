docker-compose up -d

docker exec -it vite /bin/sh

npm install && npm run dev
